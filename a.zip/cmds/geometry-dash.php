<?php
$shoti = '<iframe src="https://cc-project-apis-jonell-magallanes.onrender.com/gd" width="100%" height="400" frameborder="0" scrolling="no"></iframe>';
echo $shoti;
?>