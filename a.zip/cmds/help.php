<?php
//echo "<h3>Welcome to ChatWithAiOfficial! This is a web version of octobot. Hope you like it.</h3>";

echo '<fieldset style="border: 3px solid black;border-radius:8px">
	<legend style="border: 3px solid black;border-radius:8px;color:blue">Guides</legend>
<p>Welcome to <strong>ChatWithAiOfficial!</strong> This is a web version of octobot. Hope you like it. </p>

	</fieldset>';
?>
