<?php
$shoti = '<iframe src="cmds/lib/shoti.php" width="100%" height="400" frameborder="0" scrolling="no"></iframe>';
echo $shoti;
?>