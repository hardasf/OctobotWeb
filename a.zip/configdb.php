<?php
// Replace with your database credentials
$servername = "sql307.hstn.me";
$username = "mseet_35908237";
$password = "rejard07";
$dbname = "mseet_35908237_octo";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>